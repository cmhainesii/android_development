package com.zybooks.cs360project3charleshaines.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.cs360project3charleshaines.R;
import com.zybooks.cs360project3charleshaines.model.Item;
import com.zybooks.cs360project3charleshaines.repo.ItemRepository;
import com.zybooks.cs360project3charleshaines.repo.UserRepository;
import com.zybooks.cs360project3charleshaines.util.Utility;

public class EditItemActivity extends AppCompatActivity {

    // Declare variables

    // Bundle string identifiers
    public final static String EXTRA_ITEM_ID = "com.cs360.edit_item";

    // Reference to the current item.
    private Item currentItem = null;

    // Reference to the item repo.
    private ItemRepository itemRepository;

    // UI Controls
    private EditText nameText;
    private EditText quantityText;
    private TextView errorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        // Register UI components
        nameText = findViewById(R.id.item_name_edit);
        quantityText = findViewById(R.id.item_quantity_edit);
        errorText = findViewById(R.id.error_edit);

        // Register button listener callbacks.
        findViewById(R.id.update_button).setOnClickListener(view -> updateItem(view));
        findViewById(R.id.cancel_button_edit).setOnClickListener(view -> finish());
        findViewById(R.id.delete_button).setOnClickListener(view -> deleteItem());

        // Get the item ID passed in by DisplayInventoryActivity.
        Intent intent = getIntent();
        long itemId = intent.getLongExtra(EXTRA_ITEM_ID, 0);

        // Retrieve item from item repo.
        itemRepository = ItemRepository.getInstance(this);
        itemRepository.getItemAsync(itemId, item -> {
            currentItem = item;
            runOnUiThread(() -> {
                nameText.setText(currentItem.getName());
                quantityText.setText(String.valueOf(currentItem.getQuantity()));
            });
        });

        // Set focus to the name field.
        nameText.requestFocus();
    }

    // Callback to delete the current item. Returns to DisplayInventoryActivity afterwards.
    private void deleteItem() {
        itemRepository.deleteItem(currentItem);
        Intent intent = new Intent(this, DisplayInventoryActivity.class);
        finish();
    }

    // Callback to save the current item and update it's entry in the item repo.
    private void updateItem(View view) {

        // Hide software keyboard and validate the form has been filled out
        Utility.hideSoftKeyboard(this, view);

        if (!validateForm()) {
            return;
        }

        // Get the name and quantity from the UI components.
        String name = nameText.getText().toString().trim();
        long quantity = Long.parseLong(quantityText.getText().toString().trim());

        // Update the currentItem and update the item repository.
        currentItem.setName(name);
        currentItem.setQuantity(quantity);

        itemRepository.updateItem(currentItem);

        // If the item quantity is less than the minimum stock threshold,
        // Send SMS notification
        if (quantity < DisplayInventoryActivity.MINIMUM_STOCK_THRESHOLD) {
            UserRepository.getInstance(this).getUserAsync(DisplayInventoryActivity.username, user -> {
                if (user.isNotificationsEnabled()) {
                    Utility.sendSms(user.getPhoneNumber(), name, String.valueOf(quantity));
                }
            });
        }

        // Our work here is finished! Make haste back to DisplayInventoryActivity!
        finish();

    }

    // Function returns true if the form has been filled out appropriately.
    // Displays an error message if validation fails.
    private boolean validateForm() {
        // Check fields are not blank
        if (nameText.getText().toString().trim().isEmpty() ||
                quantityText.getText().toString().trim().isEmpty()) {
            errorText.setText(getString(R.string.missing_name_or_qty));
            return false;
        }

        // Make sure quantity isn't somehow negative.
        long quantity = Long.parseLong(quantityText.getText().toString().trim());
        if (quantity < 0 ) {
            errorText.setText(getString(R.string.qty_negative));
            return false;
        }

        return true;
    }
}