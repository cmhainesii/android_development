package com.zybooks.cs360project3charleshaines.database;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.zybooks.cs360project3charleshaines.dao.ItemDao;
import com.zybooks.cs360project3charleshaines.dao.UserDao;
import com.zybooks.cs360project3charleshaines.model.Item;
import com.zybooks.cs360project3charleshaines.model.User;

@Database(entities = {User.class, Item.class}, version = 1)
public abstract class InventoryDatabase extends RoomDatabase {

    public abstract UserDao userDao();
    public abstract ItemDao itemDao();
}
