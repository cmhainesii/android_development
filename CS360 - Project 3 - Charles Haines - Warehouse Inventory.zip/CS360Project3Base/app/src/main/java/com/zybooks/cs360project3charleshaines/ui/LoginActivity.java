package com.zybooks.cs360project3charleshaines.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.cs360project3charleshaines.R;
import com.zybooks.cs360project3charleshaines.util.Utility;
import com.zybooks.cs360project3charleshaines.model.User;
import com.zybooks.cs360project3charleshaines.repo.UserRepository;

public class LoginActivity extends AppCompatActivity {

    // Declare Variables

    // String identifiers for bundles
    public final static String EXTRA_USERID = "com.cs360.LoginActivity.userid";

    // UI Components
    private TextView usernameText;
    private TextView passwordText;
    private TextView errorText;

    // Data components
    private UserRepository userRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Register UI component to variables
        usernameText = findViewById(R.id.username_text);
        passwordText = findViewById(R.id.password_text);
        errorText = findViewById(R.id.errorMessage);

        // Register button listeners
        findViewById(R.id.create_account_button).setOnClickListener(view -> addUser(view));
        findViewById(R.id.login_button).setOnClickListener(view -> login(view));

        // Get an instance of the user repo.
        userRepository = UserRepository.getInstance(getApplicationContext());
    }


    // Handles login. Activated by clicking login button.
    private void login(View view) {

        boolean success = false;

        // Hide any previously displayed error and hide the
        // software keyboard so it doesn't cover anything
        Utility.clearErrorText(errorText);
        Utility.hideSoftKeyboard(this, view);

        // Stop here and display an error if username or password text fields are blank
        if(!validateForm()) {
            return;
        }

        // Get username and password from UI and check if matching user is found in the
        // user repo.
        String username = usernameText.getText().toString().trim();
        String password = passwordText.getText().toString().trim();

        userRepository.getUserAsync(username, user -> {
            // If user is found, and password matches entry in user repo, start
            // display inventory activity.
            if (user != null && user.getPassword().equals(password)) {
                Intent intent = new Intent(LoginActivity.this, DisplayInventoryActivity.class);
                intent.putExtra(EXTRA_USERID, user.getUsername());
                startActivity(intent);
            } else {
                // User not found or password doesn't match. Display error message.
                runOnUiThread(() -> {
                    errorText.setText(getString(R.string.user_pass_not_found));
                });
            }
        });

    }

    // Function to add user to the user repo. Activated by clicking
    // the create account button.
    private void addUser(View view) {
        Utility.clearErrorText(errorText);
        Utility.hideSoftKeyboard(this, view);

        // Validate the form has been filled out correctly. If not, stop here.
        // vaildateForm() will display an appropriate error message if validation fails.
        if (!validateForm()) {
            return;
        }

        // Parse username and password from UI.
        String username = usernameText.getText().toString().trim();
        String password = passwordText.getText().toString().trim();

        // If user exists already, show an error message.
        userRepository.getUserAsync(username, user -> {
            if (user != null) {
                errorText.setText(getString(R.string.username_exists));
            } else {
                // User does not already exist, add user to the user repo.
                User newUser = new User(0);
                newUser.setUsername(username);
                newUser.setPassword(password);
                newUser.setNotificationsEnabled(false);
                userRepository.addUserAsync(newUser, () -> {
                });

                // Log in as the newly created user. login() will make use of
                // the username and password in the edittext.
                runOnUiThread(() -> login(view));
            }
        });
    }


    // Function to validate the form. Will check that fields are not empty
    // and display an appropriate error message if needed.
    private boolean validateForm() {
        if (usernameText.getText().toString().trim().isEmpty() ||
            passwordText.getText().toString().trim().isEmpty()) {
            errorText.setText(getString(R.string.blank_login_field));
            return false;
        }
        return true;
    }
}