package com.zybooks.cs360project3charleshaines.repo;

import android.content.Context;
import androidx.room.Room;
import com.zybooks.cs360project3charleshaines.dao.UserDao;
import com.zybooks.cs360project3charleshaines.database.InventoryDatabase;
import com.zybooks.cs360project3charleshaines.model.User;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UserRepository {

    private static UserRepository users;
    private final UserDao userDao;
    private final ExecutorService executorService;

    public static UserRepository getInstance(Context context) {
        if (users == null) {
            users = new UserRepository(context);
        }
        return users;
    }

    private UserRepository(Context context) {
        InventoryDatabase database = Room.databaseBuilder(context, InventoryDatabase.class,
                        "data.db")
                .build();

        userDao = database.userDao();
        executorService = Executors.newSingleThreadExecutor();
    }

    public void getUserAsync(String username, GetUserCallback callback) {
        executorService.execute(() -> {
            User user = userDao.getUser(username);
            callback.onUserLoaded(user);
        });
    }

    public void addUserAsync(User user, AddUserCallback callback) {
        executorService.execute(() -> {
            long userId = userDao.addUser(user);
            user.setId(userId);
            callback.onUserAdded();
        });
    }

    public List<User> getUsers() {
        return userDao.getUsers();
    }

    public void updateUser(User user) {
        userDao.updateUser(user);
    }

    public interface GetUserCallback {
        void onUserLoaded(User user);
    }

    public interface AddUserCallback {
        void onUserAdded();
    }
}
