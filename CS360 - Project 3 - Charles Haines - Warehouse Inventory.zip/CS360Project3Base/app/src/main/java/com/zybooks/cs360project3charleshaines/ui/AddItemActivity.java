package com.zybooks.cs360project3charleshaines.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import com.zybooks.cs360project3charleshaines.R;
import com.zybooks.cs360project3charleshaines.model.Item;
import com.zybooks.cs360project3charleshaines.repo.ItemRepository;
import com.zybooks.cs360project3charleshaines.util.Utility;

public class AddItemActivity extends AppCompatActivity {

    // Declare variables

    // UI Components
    private TextView nameText;
    private TextView quantityText;
    private TextView errorText;

    // Data components
    private ItemRepository itemRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Register UI components
        nameText = findViewById(R.id.item_name_add);
        quantityText = findViewById(R.id.item_quantity_add);
        errorText = findViewById(R.id.error_add);

        // Register button listener callbacks
        findViewById(R.id.add_button).setOnClickListener(view -> addItem(view));
        findViewById(R.id.cancel_button_add).setOnClickListener(view -> finish());

        // Get instance to item repo.
        itemRepository = ItemRepository.getInstance(this);


    }

    // Callback for the add item button. Adds item to the item repo.
    private void addItem(View view) {

        // Hide the software keyboard and validate the form has been filled out appropriately.
        Utility.hideSoftKeyboard(this, view);
        if (!validateForm()) {
            return;
        }

        // Get the name and quantity from the UI components.
        String name = nameText.getText().toString().trim();
        long quantity = Long.parseLong(quantityText.getText().toString().trim());

        // Instantiate an item and add it to the item repo.
        Item newItem = new Item();
        newItem.setName(name);
        newItem.setQuantity(quantity);

        itemRepository.addItemAsync(newItem);

        // Mission accomplished. Return to home base (DisplayInventoryActivity).
        finish();
    }

    // Function to validate the form has been filled out accurately.
    // Displays an appropriate error message if validation fails.
    private boolean validateForm() {
        if (nameText.getText().toString().trim().isEmpty() ||
                quantityText.getText().toString().trim().isEmpty()) {
            errorText.setText(getString(R.string.missing_name_or_qty));
            return false;
        }
        long quantity = Long.parseLong(quantityText.getText().toString().trim());
        if (quantity < 0) {
            errorText.setText(getString(R.string.qty_negative));
            return false;
        }
        return true;
    }
}