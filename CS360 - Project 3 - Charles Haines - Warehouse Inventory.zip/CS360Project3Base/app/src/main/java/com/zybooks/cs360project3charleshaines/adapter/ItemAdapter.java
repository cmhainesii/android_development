package com.zybooks.cs360project3charleshaines.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.cs360project3charleshaines.R;
import com.zybooks.cs360project3charleshaines.model.Item;

import java.util.List;
import java.util.zip.Inflater;

public class ItemAdapter  extends RecyclerView.Adapter<ItemAdapter.ItemHolder> {

    private List<Item> items;

    public interface OnItemClickListner {
        void onItemClick(Item item);
    }

    private OnItemClickListner listener;

    public ItemAdapter(List<Item> items, OnItemClickListner listener) {

        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View rowView = inflater.inflate(R.layout.item_row, parent, false);
        return new ItemHolder(rowView);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @Override
    public void onBindViewHolder(@NonNull ItemHolder holder, int position) {
        Item item = items.get(position);
        holder.itemName.setText(item.getName());
        holder.itemQuantity.setText(String.valueOf(item.getQuantity()));
        holder.rowContainer.setOnClickListener((itemView) -> {
            listener.onItemClick(item);
        });

    }

    public class ItemHolder extends RecyclerView.ViewHolder {

        private TextView itemName;
        private TextView itemQuantity;
        private CardView rowContainer;

        public ItemHolder(@NonNull View itemView) {
            super(itemView);

            itemName = itemView.findViewById(R.id.itemNameRow);
            itemQuantity = itemView.findViewById(R.id.itemQuantityRow);
            rowContainer = itemView.findViewById(R.id.rowContainer);
        }
    }
}
