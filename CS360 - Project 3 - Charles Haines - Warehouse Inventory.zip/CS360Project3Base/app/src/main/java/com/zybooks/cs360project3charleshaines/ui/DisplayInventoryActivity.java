package com.zybooks.cs360project3charleshaines.ui;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.cs360project3charleshaines.R;
import com.zybooks.cs360project3charleshaines.adapter.ItemAdapter;
import com.zybooks.cs360project3charleshaines.model.Item;
import com.zybooks.cs360project3charleshaines.repo.ItemRepository;
import com.zybooks.cs360project3charleshaines.repo.UserRepository;
import com.zybooks.cs360project3charleshaines.util.Utility;

import java.util.List;

public class DisplayInventoryActivity extends AppCompatActivity
    implements ItemAdapter.OnItemClickListner {

    // Declare variables

    public static final int MINIMUM_STOCK_THRESHOLD = 25;

    // UI Components
    private RecyclerView rvItems;

    // Data Components
    private ItemRepository itemRepository;

    // Store the username of the user who logged in. Used by other activities.
    public static String username;

    // Boolean used to stop duplication notifications from being
    // sent. Set to true after notifications are sent when the user logs in.
    // Notifications still occur if quantities of items are updated manually.
    boolean notificationsSent = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_inventory);

        // Retrieve username of the user who logged in.
        Intent intent = getIntent();
        username = intent.getStringExtra(LoginActivity.EXTRA_USERID);

        // Register UI components.
        rvItems = findViewById(R.id.rvItems);

        // Get instance of item repo.
        itemRepository = ItemRepository.getInstance(this);

        // Set up adapter to populate the list of items.
        // Observe the repository so changes are displayed as the database is
        // updated.
        itemRepository.getItems().observe(this, items -> {
            rvItems.setAdapter(new ItemAdapter(items, this));
            rvItems.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            rvItems.getAdapter().notifyDataSetChanged();

            if (!notificationsSent && items != null) {
                sendLowQuantityNotifications(items);
            }

        });

        // Register button listeners to appropriate functions
        findViewById(R.id.logout_button).setOnClickListener(view -> logout());
        findViewById(R.id.add_item_fab).setOnClickListener(view -> addItem());
        findViewById(R.id.toggle_notifications).setOnClickListener(view ->
                enterNotificationSettings());
    }

    // Function to send SMS notifications for any items with a quantity less than 25 on login.
    // This round of notifications is only sent once. Per item notifications are sent
    // as quantities are updated as well.
    private void sendLowQuantityNotifications(List<Item> items) {
        UserRepository.getInstance(this).getUserAsync(username, user -> {
            // Check that notifications are enabled and request SMS permission if needed.
            if (items != null && items.size() > 0 && !notificationsSent && user.isNotificationsEnabled()) {
                notificationsSent = true;
                for (Item item : items) {
                    if (item.getQuantity() < MINIMUM_STOCK_THRESHOLD) {
                        if (Utility.hasSmsPermission(this)) {
                            Utility.sendSms(user.getPhoneNumber(), item.getName(), String.valueOf(item.getQuantity()));
                        }
                        else {
                            Utility.requestSmsPermission(this, this ,false);
                        }
                    }
                }
            }
        });
    }

    // Function to start to the notifications activity. Requests SMS permission
    // if not already granted first.
    private void enterNotificationSettings() {
        if (Utility.hasSmsPermission(this)) {
            Intent intent = new Intent(this, EnableNotificationsActivity.class);
            startActivity(intent);
        } else {
            Utility.requestSmsPermission(this, this, true);
        }
    }

    // Ensure the recyclerview is observing the itemRepository on resuming this activity.
    @Override
    protected void onResume() {
        super.onResume();

        itemRepository.getItems().observe(this, items -> {
            rvItems.setAdapter(new ItemAdapter(items, this));
            rvItems.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            rvItems.getAdapter().notifyDataSetChanged();
        });
    }


    // Start the activity to add an item to the inventory repo.
    private void addItem() {
        Intent intent = new Intent(this, AddItemActivity.class);
        startActivity(intent);

    }

    // Go back to the login screen
    private void logout() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    // Callback for when an item is clicked. Opens the EditItemActivity.
    @Override
    public void onItemClick(Item item) {
        Intent intent = new Intent(this, EditItemActivity.class);
        intent.putExtra(EditItemActivity.EXTRA_ITEM_ID, item.getId());
        startActivity(intent);
    }
}