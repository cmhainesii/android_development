package com.zybooks.cs360project3charleshaines.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import com.zybooks.cs360project3charleshaines.R;
import com.zybooks.cs360project3charleshaines.repo.UserRepository;
import com.zybooks.cs360project3charleshaines.util.Utility;

import java.util.concurrent.atomic.AtomicBoolean;

public class EnableNotificationsActivity extends AppCompatActivity {

    // Declare variables

    // UI Components
    private SwitchCompat enabledSwitch;
    private EditText phoneText;
    private TextView errorText;

    // Data components
    private UserRepository userRepository;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enable_notifications);

        // Register UI components.
        enabledSwitch = findViewById(R.id.enableNotificationsSwitch);
        phoneText = findViewById(R.id.phone_number);
        errorText = findViewById(R.id.error_notify);

        // Get an instance to the user repo.
        userRepository = UserRepository.getInstance(this);

        // Get a User() object of the currently logged in user.
        // Populate the UI components with the current settings
        // for the logged on user.
        userRepository.getUserAsync(DisplayInventoryActivity.username, user -> {
            String phoneNumber = user.getPhoneNumber();

            if (phoneNumber != null && !phoneNumber.isEmpty()){
                runOnUiThread(() -> phoneText.setText(phoneNumber));
            }
            runOnUiThread(() -> enabledSwitch.setChecked(user.isNotificationsEnabled()));
            ;
        });

        // Register button listener callbacks
        findViewById(R.id.savePhoneButton).setOnClickListener(view -> savePhone(view));
        findViewById(R.id.cancel_button_notification).setOnClickListener(view -> finish());
    }

    // Callback for the save button. Saves the user's notification settings.
    // If an invalid phone number is entered, displays an appropriate error message.
    private void savePhone(View view) {

        Utility.clearErrorText(errorText);
        if(!validateForm()) {
            return;
        }

        userRepository.getUserAsync(DisplayInventoryActivity.username, user-> {
            user.setNotificationsEnabled(enabledSwitch.isChecked());
            if (enabledSwitch.isChecked()) {
                user.setPhoneNumber(phoneText.getText().toString().trim());
            }
            userRepository.updateUser(user);
        });
        finish();
    }

    // Validate the form is filled out with a valid phone number.
    private boolean validateForm() {
        if (enabledSwitch.isChecked() && phoneText.getText().toString().trim().isEmpty()) {
            errorText.setText(getString(R.string.phone_missing));
            return false;
        }
        if (enabledSwitch.isChecked() && phoneText.getText().toString().trim().length() != 10) {
            errorText.setText(getString(R.string.phone_invalid));
            return false;
        }
        return true;
    }
}