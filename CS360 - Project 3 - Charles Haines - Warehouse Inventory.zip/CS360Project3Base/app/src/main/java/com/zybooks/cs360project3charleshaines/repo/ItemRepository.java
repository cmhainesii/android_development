package com.zybooks.cs360project3charleshaines.repo;

import android.content.Context;
import androidx.lifecycle.LiveData;
import androidx.room.Room;
import com.zybooks.cs360project3charleshaines.dao.ItemDao;
import com.zybooks.cs360project3charleshaines.database.InventoryDatabase;
import com.zybooks.cs360project3charleshaines.model.Item;
import com.zybooks.cs360project3charleshaines.model.User;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ItemRepository {

    private static ItemRepository items;
    private final ItemDao itemDao;
    private final ExecutorService executorService;

    private static Context context;

    public static ItemRepository getInstance(Context context) {
        if (items == null) {
            items = new ItemRepository(context);
        }
        return items;
    }

    private ItemRepository(Context context) {
        InventoryDatabase database = Room.databaseBuilder(context, InventoryDatabase.class,
                        "data.db")
                .build();

        itemDao = database.itemDao();
        executorService = Executors.newSingleThreadExecutor();
        this.context = context;

    }

    public LiveData<List<Item>> getItems() {
        return itemDao.getItems();
    }

    public void getItemAsync(long itemId, GetItemCallback callback) {
        executorService.execute(() -> {
            Item item = itemDao.getItem(itemId);
            callback.onItemLoaded(item);
        });
    }

    public void addItemAsync(Item item) {
        executorService.execute(() -> {
            long itemIdResult = itemDao.addItem(item);
            item.setId(itemIdResult);

        });
    }

    public void deleteItem(Item item) {
        executorService.execute(() -> itemDao.deleteItem(item));
    }

    public void updateItem(Item item) {
        executorService.execute(() -> itemDao.updateItem(item));

    }

    public interface GetItemCallback {
        void onItemLoaded(Item item);
    }

    public interface AddItemCallback {
        void onItemAdded();
    }
}