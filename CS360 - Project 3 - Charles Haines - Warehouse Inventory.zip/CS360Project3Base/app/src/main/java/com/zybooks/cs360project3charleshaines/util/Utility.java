package com.zybooks.cs360project3charleshaines.util;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.zybooks.cs360project3charleshaines.ui.EnableNotificationsActivity;

public class Utility {

    // Hide the software keyboard
    public static void hideSoftKeyboard(Context context, View view) {
        InputMethodManager inputMethodManager = (InputMethodManager)
                context.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    // Clears the text from a TextView
    public static void clearErrorText(TextView textField) {
        textField.setText("");
    }

    // Sends a SMS message.
    // Arguments: (String) Phone number
    //            (String) Item name
    //            (String) Item quantity
    public static void sendSms(String phoneNumber, String itemName, String quantity) {
        SmsManager smsManager = SmsManager.getDefault();

        String message = "Inventory Low Alert! Item: " + itemName + " Qty: " + quantity;
        smsManager.sendTextMessage(phoneNumber, null, message, null,
                null);
    }

    // Requests SMS permission for the app from the operating system.
    // If redirect is true, starts the EnableNotificationsActivity.
    public static void requestSmsPermission(Activity activity, Context context,
                                      boolean redirectToNotificationsScreen) {
        final int REQUEST_SMS_PERMISSION = 1234;

        ActivityCompat.requestPermissions(
                activity, new String[]{"android.permission.SEND_SMS"},
                REQUEST_SMS_PERMISSION
        );
        if (redirectToNotificationsScreen) {
            Intent intent = new Intent(context, EnableNotificationsActivity.class);
            activity.startActivity(intent);
        }
    }

    // Returns true if the app has SMS permission from the operating system.
    public static boolean hasSmsPermission(Context context) {
        return ContextCompat.checkSelfPermission(
                context, "android.permission.SEND_SMS"
        ) == PackageManager.PERMISSION_GRANTED;
    }
}


